package com.dharma.infoBook.infoBookservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InfoBookServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(InfoBookServiceApplication.class, args);
	}

}
