package com.dharmaclient.dharmaclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DharmaClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
